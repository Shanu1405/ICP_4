import pandas
import matplotlib.pyplot
# Read the CSV file into a Pandas dataframe
df = pandas.read_csv('data.csv')
print("Statistics of Data:\n{} \n".format(df.describe()))
# Check for null values
print("Number of null Values in data per column: \n{} \n".format(df.isnull().sum()))

# Replace null values with the mean
df.fillna(df.mean(), inplace=True)

# Aggregate data for two columns
cols = ['Duration', 'Calories']
agg = df[cols].agg(['min', 'max', 'count', 'mean'])
print("Aggrigate data of two columns (Duration, Calories) : \n {} \n".format(agg))

# Filter data with calories between 500 and 1000
df_500_1000 = df[(df['Calories'] >= 500) & (df['Calories'] <= 1000)]
print("Data with calories between 500 and 1000: \n {} \n".format(df_500_1000))
# Filter data with calories > 500 and pulse < 100
df_500_pulse = df[(df['Calories'] > 500) & (df['Pulse'] < 100)]
print("Data with calories > 500 and pulse < 100: \n {} \n".format(df_500_pulse))
# Create new dataframe without "Maxpulse" column
df_modified = df.drop('Maxpulse', axis=1)

# Delete "Maxpulse" column from the main df dataframe
df.drop('Maxpulse', axis=1, inplace=True)

# Convert "Calories" column to int datatype
df['Calories'] = df['Calories'].astype(int)

# Scatter plot for "Duration" and "Calories"

matplotlib.pyplot.scatter(df['Duration'], df['Calories'])
matplotlib.pyplot.xlabel('Duration')
matplotlib.pyplot.ylabel('Calories')
matplotlib.pyplot.show()
